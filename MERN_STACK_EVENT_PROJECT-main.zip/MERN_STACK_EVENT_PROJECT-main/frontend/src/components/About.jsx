import React from "react";

const About = () => {
  return (
    <section className="about container">
      <h4>Events</h4>
      <h2>ABOUT</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet facilis
        voluptas provident animi corrupti dolor, ipsum deleniti perferendis
        veniam neque labore enim odio ratione. Ad commodi rem corporis soluta
        sed reprehenderit a quasi nihil, odit aperiam exercitationem? Suscipit
        rerum quibusdam inventore atque veritatis accusantium excepturi,
        molestias optio perferendis aliquam harum, amet dolore! Animi
        consequuntur officiis modi eius cumque reiciendis harum ipsum
        praesentium numquam fugit? Consequatur eveniet recusandae harum hic. Eum
        illo praesentium optio accusantium, hic quibusdam delectus voluptatem
        qui a officiis dolorum minima cum illum culpa doloremque quia quidem aut
        sed laudantium nam repudiandae sequi similique! Esse natus at quas?
      </p>
    </section>
  );
};

export default About;
